%calculate breakdown.

run_names = {'a_Run_R0_3-0_VE_0-0_2021_08_26',...
    'b_Run_R0_3-0_VE_0-9_2021_08_26',...
    'c_Run_R0_6-0_VE_0-0_2021_08_26',...
    'd_Run_R0_6-0_VE_0-8_2021_08_26'};





for r_i = 1:numel(run_names)
    
    outfile_name = [run_names{r_i} '_BD.csv'];
    
    % n events | e-days | FoI
    prime_iso_ext = [0, 0, 0];
    prime_iso_noext = [0, 0, 0];
    prime_noiso_ext = [0, 0, 0];
    prime_noiso_noext = [0, 0, 0];
    
    sec_iso_ext = [0, 0, 0];
    sec_iso_noext = [0, 0, 0];
    sec_noiso_ext = [0, 0, 0];
    sec_noiso_noext = [0, 0, 0];
    
    T_list = readtable([run_names{r_i}, '\Traveller_breach.csv']);
    
    for i = 1:size(T_list, 1)
        
        if T_list.index_case(i) == 1
            if T_list.days_in_iso(i) > 0
                if T_list.days_in_extended_quar(i) > 0
                    prime_iso_ext(1) = prime_iso_ext(1) + 1;
                    prime_iso_ext(2) = prime_iso_ext(2) + T_list.exposure_days(i);
                    prime_iso_ext(3) = prime_iso_ext(3) + T_list.FoI_community(i);
                end
            end
        end
        
        if T_list.index_case(i) == 1
            if T_list.days_in_iso(i) > 0
                if T_list.days_in_extended_quar(i) == 0
                    prime_iso_noext(1) = prime_iso_noext(1) + 1;
                    prime_iso_noext(2) = prime_iso_noext(2) + T_list.exposure_days(i);
                    prime_iso_noext(3) = prime_iso_noext(3) + T_list.FoI_community(i);
                end
            end
        end
        
        if T_list.index_case(i) == 1
            if T_list.days_in_iso(i) == 0
                if T_list.days_in_extended_quar(i) > 0
                    prime_noiso_ext(1) = prime_noiso_ext(1) + 1;
                    prime_noiso_ext(2) = prime_noiso_ext(2) + T_list.exposure_days(i);
                    prime_noiso_ext(3) = prime_noiso_ext(3) + T_list.FoI_community(i);
                end
            end
        end
        
        if T_list.index_case(i) == 1
            if T_list.days_in_iso(i) == 0
                if T_list.days_in_extended_quar(i) == 0
                    prime_noiso_noext(1) = prime_noiso_noext(1) + 1;
                    prime_noiso_noext(2) = prime_noiso_noext(2) + T_list.exposure_days(i);
                    prime_noiso_noext(3) = prime_noiso_noext(3) + T_list.FoI_community(i);
                end
            end
        end
        
        %secondary cases
        if T_list.index_case(i) == 0
            if T_list.days_in_iso(i) > 0
                if T_list.days_in_extended_quar(i) > 0
                    sec_iso_ext(1) = sec_iso_ext(1) + 1;
                    sec_iso_ext(2) = sec_iso_ext(2) + T_list.exposure_days(i);
                    sec_iso_ext(3) = sec_iso_ext(3) + T_list.FoI_community(i);
                end
            end
        end
        
        if T_list.index_case(i) == 0
            if T_list.days_in_iso(i) > 0
                if T_list.days_in_extended_quar(i) == 0
                    sec_iso_noext(1) = sec_iso_noext(1) + 1;
                    sec_iso_noext(2) = sec_iso_noext(2) + T_list.exposure_days(i);
                    sec_iso_noext(3) = sec_iso_noext(3) + T_list.FoI_community(i);
                end
            end
        end
        
        if T_list.index_case(i) == 0
            if T_list.days_in_iso(i) == 0
                if T_list.days_in_extended_quar(i) > 0
                    sec_noiso_ext(1) = sec_noiso_ext(1) + 1;
                    sec_noiso_ext(2) = sec_noiso_ext(2) + T_list.exposure_days(i);
                    sec_noiso_ext(3) = sec_noiso_ext(3) + T_list.FoI_community(i);
                end
            end
        end
        
        if T_list.index_case(i) == 0
            if T_list.days_in_iso(i) == 0
                if T_list.days_in_extended_quar(i) == 0
                    sec_noiso_noext(1) = sec_noiso_noext(1) + 1;
                    sec_noiso_noext(2) = sec_noiso_noext(2) + T_list.exposure_days(i);
                    sec_noiso_noext(3) = sec_noiso_noext(3) + T_list.FoI_community(i);
                end
            end
        end
        
    end
    
    label_1 = {'primary';'primary';'primary';'primary';'secondary';'secondary';'secondary';'secondary'};
    label_2 = {'iso';'iso';'no iso'; 'no iso'; 'iso';'iso';'no iso'; 'no iso'};
    label_3 = {'ext';'no ext'; 'ext';'no ext'; 'ext';'no ext'; 'ext';'no ext'};
    
    FoI = [ prime_iso_ext(3);
            prime_iso_noext(3);
            prime_noiso_ext(3);
            prime_noiso_noext(3);
            sec_iso_ext(3);
            sec_iso_noext(3); 
            sec_noiso_ext(3);
            sec_noiso_noext(3)];
        
    e_days = [ prime_iso_ext(2);
            prime_iso_noext(2);
            prime_noiso_ext(2);
            prime_noiso_noext(2);
            sec_iso_ext(2);
            sec_iso_noext(2); 
            sec_noiso_ext(2);
            sec_noiso_noext(2)]  ; 
        
    n_breach = [ prime_iso_ext(1);
            prime_iso_noext(1);
            prime_noiso_ext(1);
            prime_noiso_noext(1);
            sec_iso_ext(1);
            sec_iso_noext(1); 
            sec_noiso_ext(1);
            sec_noiso_noext(1)]   ; 
        
    outtable = table(label_1, label_2, label_3, n_breach, e_days, FoI);
    
    writetable(outtable, outfile_name);
    
end